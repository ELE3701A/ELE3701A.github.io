# Section 3 - Numérisation 

Cette section explore les bases de la numérisation des signaux, une étape clé dans les systèmes de communication modernes. Elle introduit tout d’abord les principes fondamentaux de l’échantillonnage, qui permettent de convertir un signal continu en une série d’échantillons discrets, garantissant ainsi une représentation fidèle selon le théorème de Nyquist-Shannon. Les applications pratiques de l’échantillonnage, notamment le calcul du débit maximal d’information et les modulations analogiques d’impulsions, y sont abordées.

Ensuite, la section s’intéresse à la modulation par impulsions codées (*Pulse Code Modulation*; PCM), un processus crucial pour la transmission numérique des signaux. Les concepts de codage et de quantification sont détaillés pour expliquer comment les niveaux d’amplitude sont discrétisés en valeurs numériques.

Enfin, la section conclut par une étude du multiplexage temporel, une technique permettant de partager efficacement un canal de communication entre plusieurs utilisateurs. Les principes de base et le format des trames sont explorés pour illustrer son importance dans les systèmes à grande échelle.

Ensemble, ces notions établissent une base solide pour comprendre la numérisation et son rôle central dans les télécommunications modernes.

## Numérisation

La **numérisation** implique la transformation d'un signal du temps continu au temps discret (échantillonnage), puis en valeurs discrètes (quantification).  La numérisation est réalisée par un **convertisseur analogique-numérique** (*analog-to-digital converter*; ADC).
Sa performance  généralement indiquée par la fréquence d’échantillonnage et le nombre de bits par échantillon.
Le processus inverse, qui consiste à convertir un signal numérique en un signal continu, est effectué par un **convertisseur numérique-analogique** (*digital-to-analog converter*, DAC). 

### Échantillonnage

(def-chantillonnage)=
Définition: Échantillonnage  
: L’**échantillonnage** est la lecture d’un signal, $m(t)$ à intervalles réguliers, $T_E$ seconds. Donc on utilise une fréquence d'échantionnage de $f_E$ Hz. La problématique principale liée à l’échantillonnage **sans perdre d’information**.  Cela nous permet d'utiliser l'interpolation et de reconstituer le signal original. Nous représenterons le signal échantillonné comme $m_E(t)$.


Soit $m(t)$ un signal limité (dans le domaine des fréquences) à $B$ Hz. Le signal échantillonné est :
$$
g_E(t) = g(t) \delta_{T_E}(t) = \sum_{n=-\infty}^{\infty} g(nT_E) \delta(t - nT_E)
$$
où $\delta_{T_E}(t)$ représente un train d'impulsions de Dirac, défini comme [](#train). Sachant que 
$$
\delta_{T_s}(t) = \sum_{n=-\infty}^{\infty} \delta (t - nT_s) = \frac{1}{T_s} \sum_{n=-\infty}^{\infty} e^{j 2\pi n f_s t}
$$
la transformée de Fourier de $g_E(t)$ peut être écrite comme 
$$
\delta_{T_s}(t) = \sum_{n=-\infty}^{\infty} \delta (t - nT_s) = \frac{1}{T_s} \sum_{n=-\infty}^{\infty} e^{j 2\pi n f_s t}
$$

Le signal original $g(t)$ peut être récupéré sans perte à partir de $g_E(t)$ si 
$$
f_s = \frac{1}{T_E} > 2B \quad \text{échantillons/seconde}
$$
où :
- $f_E$ : Fréquence (ou taux) d’échantillonnage  
- $2B$ : Taux de Nyquist  
- $g(nT_E)$ : Valeur de $g(t)$ à $t = nT_E$ sec.




(def-chantillonnage)=
Définition: chevauchement (*aliasing*) 
: Nous devons nous conformer aux critères de Nquist, sinon nous observons un effet de **chevauchement**.   Le chevauchement se produit lorsqu'un signal est échantillonné à une fréquence **inférieure** au **taux de Nyquist** ($f_E < 2B$). Ce chevauchement entraîne une **distorsion**, où différentes fréquences deviennent indiscernables.

:::{warning} Attention
Comment éviter le chevauchement :
1. **Augmenter la fréquence d’échantillonnage** pour que $f_s > 2B$. Mais notez que échantillonnage au-dessus du taux de Nyquist réduira l'efficacité spectrale (certaines bandes ne sont pas utilisées).


2. **Appliquer un anti-chevauchment** avant l’échantillonnage pour éliminer les composantes fréquentielles supérieures à $B$ (i.e. pour limiter la largeur de bande de $g(t)$.
:::
 

Applications du théorème d'échantillonnage : 
- Débit maximal d'information
- Modulations analogiques d’impulsions
 

### Quantification


(def-quantification)=
Définition: Quantification
: La **quantification** est la lecture d'un signal  avec une précision finie. Une conséquence importante de ce processus est l'ajout du  bruit de quantification. La quantification est utilisée après l'échantillonnage dans le processus de numérisation d'un signal.  Nous représenterons le signal après la quantificationm comme $m_E(t)$ 

## Numérisation 
### Reconstruction idéale



### Reconstruction pratique (interpolation) 

### Égalisateur (*equalizer*)

## Modulation par impulsions codées (*Pulse Code Modulation*; PCM)

##  Multiplexage temporel