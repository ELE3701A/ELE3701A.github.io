# Section 3 - Numérisation 

Cette section explore les bases de la numérisation des signaux, une étape clé dans les systèmes de communication modernes. Elle introduit tout d’abord les principes fondamentaux de l’échantillonnage, qui permettent de convertir un signal continu en une série d’échantillons discrets, garantissant ainsi une représentation fidèle selon le théorème de Nyquist-Shannon. Les applications pratiques de l’échantillonnage, notamment le calcul du débit maximal d’information et les modulations analogiques d’impulsions, y sont abordées.

Ensuite, la section s’intéresse à la modulation par impulsions codées (*Pulse Code Modulation*; PCM), un processus crucial pour la transmission numérique des signaux. Les concepts de codage et de quantification sont détaillés pour expliquer comment les niveaux d’amplitude sont discrétisés en valeurs numériques.

Enfin, la section conclut par une étude du multiplexage temporel, une technique permettant de partager efficacement un canal de communication entre plusieurs utilisateurs. Les principes de base et le format des trames sont explorés pour illustrer son importance dans les systèmes à grande échelle.

Ensemble, ces notions établissent une base solide pour comprendre la numérisation et son rôle central dans les télécommunications modernes.

## Numérisation

La **numérisation** implique la transformation d'un signal du temps continu au temps discret (échantillonnage), puis en valeurs discrètes (quantification).  La numérisation est réalisée par un **convertisseur analogique-numérique** (*analog-to-digital converter*; ADC).
Sa performance  généralement indiquée par la fréquence d’échantillonnage et le nombre de bits par échantillon.
Le processus inverse, qui consiste à convertir un signal numérique en un signal continu, est effectué par un **convertisseur numérique-analogique** (*digital-to-analog converter*, DAC). 

### Échantillonnage

(def-chantillonnage)=
Définition: Échantillonnage  
: L’**échantillonnage** est la lecture d’un signal, $m(t)$ à intervalles réguliers, $T_E$ seconds ($T_E$ est la période d’échantillonnage). Donc on utilise une fréquence d'échantionnage de $f_E$ Hz. La problématique principale liée à l’échantillonnage **sans perdre d’information**.  Cela nous permet d'utiliser l'interpolation et de reconstituer le signal original. Nous représenterons le signal échantillonné comme $m_E(t)$.


Soit $m(t)$ un signal limité (dans le domaine des fréquences) à $B$ Hz. Le signal échantillonné est :
$$
m_E(t) = m(t) \delta_{T_E}(t) = \sum_{n=-\infty}^{\infty} m(nT_E) \delta(t - nT_E)
$$
où $\delta_{T_E}(t)$ représente un train d'impulsions de Dirac, défini comme [](#train), et  $m(nT_E)$ représente la valeur de $m(t)$ à $t = nT_E$ sec. Sachant que 
$$
\delta_{T_E}(t) = \sum_{n=-\infty}^{\infty} \delta (t - nT_E) = \frac{1}{T_E} \sum_{n=-\infty}^{\infty} e^{j 2\pi n f_E t}
$$
la transformée de Fourier de $g_E(t)$ peut être écrite comme 
$$
M_E(f) = M(f) * \frac{1}{T_E} \sum_{n=-\infty}^{\infty} \delta(f - n f_E) = \frac{1}{T_E} \sum_{n=-\infty}^{\infty} M(f - n f_E)
$$

:::{warning} Attention
Notez que le spectre du signal d’origine devient périodique après échantillonnage avec une période de $$f_E =\frac{1}{T_E}$$ 
:::

## Reconstruction  



Selon le **théorème d'échantillonnage de Nyquist-Shannon**, un signal, $m(t)$ dont le spectre est limité à une bande de fréquences comprise entre $ -B $ et $ B $ Hz peut être parfaitement reconstruit à partir de ses échantillons **si et seulement si** la fréquence d’échantillonnage $ f_E $ respecte la condition 
$$
f_E \geq 2B
$$
Le **taux de Nyquist** ($ 2B $) est définie comme la fréquence minimale d'échantillonnage nécessaire pour éviter le **chevauchement** lors de la numérisation d'un signal. Donc le taux de Nyquist représente donc la **fréquence d'échantillonnage minimale requise** pour assurer une reconstruction fidèle du signal sans perte d’information.


 
(def-chantillonnage)=
Définition: chevauchement (*aliasing*) 
: Nous devons nous conformer aux critères de Nquist, sinon nous observons un effet de **chevauchement**.   Le chevauchement se produit lorsqu'un signal est échantillonné à une fréquence **inférieure** au **taux de Nyquist** ($f_E < 2B$). Ce chevauchement entraîne une **distorsion*irréversible** du signal, où différentes fréquences deviennent indiscernables.

:::{warning} Attention
Comment éviter le chevauchement :
1. **Augmenter la fréquence d’échantillonnage** pour que $f_E > 2B$. Mais notez que échantillonnage au-dessus du taux de Nyquist réduira l'efficacité spectrale (certaines bandes ne sont pas utilisées).


2. **Appliquer un anti-chevauchment** avant l’échantillonnage pour éliminer les composantes fréquentielles supérieures à $B$ (i.e. pour limiter la largeur de bande de $g(t)$.
:::
 


### Reconstruction idéale

Si un signal $ m(t) $ a été échantillonné avec une fréquence $ f_E \geq 2B $, la reconstruction idéale est réalisée en **filtrant le spectre du signal échantillonné** avec un **filtre passe-bas idéal** dont la réponse en fréquence est :
$$
H(f) = T_E \cdot \prod \left( \frac{f}{2B} \right) = \begin{cases} 
T_E & \text{si } |f| \leq B \\
0 & \text{si } |f| > B \end{cases} 
$$
où $ \prod(x) $ représente une fonction porte qui sélectionne uniquement les fréquences comprises entre $ -B $ et $ B $ Hz. Ce filtre passe-bas idéal élimine les copies spectrales indésirables introduites lors de l’échantillonnage.

En domain temporel, $m(t)$ peut être parfaitement reconstruit par **interpolation de sinc** :
$$
m(t) = \sum_{n=-\infty}^{\infty} m(nT_E) \text{sinc} \left(   \frac{\pi(t - nT_E)}{T_E} \right)
$$


%- $ \text{sinc}(\pi x) = \frac{\sin(\pi x)}{\pi x} $ est la fonction de cardinal de Whittaker-Shannon utilisée pour l’interpolation.
 

### Reconstruction pratique (interpolation) 


L’**interpolation** est le processus de reconstruction d'un signal continu à partir de ses échantillons discrets en utilisant un **filtre passe-bas** ayant une réponse impulsionnelle $p(t)$.

Lorsque nous ne pouvons pas créer un filtre idéal, nous pouvons utiliser un filtre pratique avec une réponse impulsionnelle p(t)p(t) qui a une durée finie dans le temps, permettant une reconstruction approximative tout en réduisant la complexité de mise en œuvre. L'interpolation peut être vue comme un filtrage de convolution du signal échantillonné $m_E(t)$ avec un **filtre passe-bas non-idéal** avec une  **réponse impulsionnelle** du filtre passe-bas $ p(t) $, qui permet de lisser les échantillons et de reconstruire un signal continu :
$$
 \widetilde{m}(t) = m_E(t) * p(t) = \sum_{n=-\infty}^{\infty} m(nT_E) p(t - nT_E)
$$
où $\widetilde{m}(t)$ est le **signal reconstruit** et  $*$ représente l’opération de **convolution**.



L'expression de la transformée de Fourier du signal reconstruit est donnée par :
$$
\widetilde{M}(f) = M_E(f) P(f) = P(f) \frac{1}{T_E} \sum_{n=-\infty}^{\infty} M(f - n f_E)
$$
où  $\tilde{G}(f) $ est le spectre du **signal reconstruit**, $ M_E(f)$ est le spectre du **signal échantillonné**, et  $ P(f)$ est la **réponse en fréquence du filtre d’interpolation** $ p(t)$. 



:::{warning}  Comment peut-on éliminer l'effet de $ p(t)$ ?
L'effet de $ p(t)$ peut être éliminé en appliquant un **égaliseur** (*equalizer*). L’égaliseur est l’équivalent d’un filtre passe bas ayant une fonction de transfert inverse  (ou annule $ p(t)$).   
Soit \( E(f) \) la **réponse en fréquence de l'égaliseur**. Notre objectif de conception est d'obtenir 
$$
E(f) P(f) =
\begin{cases} 
0, & |f| \geq f_E - B \\
T_E e^{-j 2\pi f t_0}, & |f| < B
\end{cases}
$$
où $\textcolor{red}{t_0}$ est un délai qui assure la causalité du filtre conçu. Notez que nous nous concentrons uniquement sur la largeur de bande du message. 
:::


 


Applications du théorème d'échantillonnage : 
- Débit maximal d'information
- Modulations analogiques d’impulsions
 

## Quantification


(def-quantification)=
Définition: Quantification
: La **quantification** est la lecture d'un signal  avec une précision finie. Une conséquence importante de ce processus est l'ajout du  bruit de quantification. La quantification est utilisée après l'échantillonnage dans le processus de numérisation d'un signal.  Nous représenterons le signal après la quantification comme $m_E(t)$ 


# Définition de la Quantification

## **Quantification comme Fonction d'Entrée et de Sortie**
La **quantification** est le processus qui transforme un signal d’entrée **continu** en un signal de sortie **discret**, en l'arrondissant à l’un des niveaux prédéfinis. Elle peut être représentée mathématiquement par une fonction de quantification \( Q(x) \) :

$$
y = Q(x)
$$

où :

- \( x \) est l’**entrée du système** (valeur continue),
- \( y \) est la **sortie quantifiée** (valeur discrète),
- \( Q(x) \) applique un **arrondi** ou un **troncage** aux valeurs disponibles.

En général, la quantification est réalisée par un **convertisseur analogique-numérique (CAN)**.

## **Exemples de Quantification**
1. **Quantification Uniforme**  
   Lorsque les niveaux de quantification sont **équidistants**, on parle de **quantification uniforme**. L'intervalle entre chaque niveau est appelé **pas de quantification** \( \Delta \).

2. **Quantification Non Uniforme**  
   Utilisée lorsque certaines plages de valeurs doivent être plus précises (ex : **compandage en télécommunications**).

## **Nombre de Niveaux de Quantification**
Le **nombre de niveaux de quantification** \( L \) est défini par :

$$
L = 2^N
$$

où :

- \( N \) est le **nombre de bits utilisés** pour représenter chaque échantillon.
- \( L \) est le **nombre total de niveaux disponibles**.

### **Exemple Numérique**
Si un **CAN** utilise **3 bits** (\( N = 3 \)), alors :

$$
L = 2^3 = 8
$$

Le signal pourra être représenté par **8 niveaux différents**.

## **Interprétation**
- **Un \( N \) plus grand** signifie une **meilleure résolution** et **moins de bruit de quantification**.
- **Un \( N \) plus petit** entraîne une **perte d’information** et une **distorsion accrue**.

🚀 **Conclusion** : La quantification est un processus essentiel en traitement du signal, utilisé en **numérisation audio, imagerie, télécommunications**, et bien d'autres domaines.





# Bruit de Quantification

## **Définition**
Le **bruit de quantification** est l'erreur introduite lorsqu'un signal analogique est converti en signal numérique par un **convertisseur analogique-numérique (CAN)**. Cette erreur est due à l’arrondi des valeurs du signal à l’un des niveaux de quantification disponibles.

## **Modèle du Bruit de Quantification**
L’échantillon quantifié est donné par :

$$
\hat{m}(nT_s) = m(nT_s) + q(nT_s)
$$

où :

- \( m(nT_s) \) est le signal d'origine,
- \( q(nT_s) \) est le bruit de quantification ajouté.

La **densité de probabilité** du bruit \( q(nT_s) \) est **uniforme**, et il est borné par :

$$
-\frac{\Delta}{2} \leq q(nT_s) < \frac{\Delta}{2}
$$

## **Caractéristiques Statistiques**
Le bruit de quantification est **centré en moyenne** et sa variance est donnée par :

$$
m_Q = E[q(nT_s)] = 0, \quad \sigma_Q^2 = \frac{m_p^2}{3L^2}
$$

(référence : Équation 5.31, page 306).

## **Rapport Signal sur Bruit de Quantification (SQNR)**
Le **rapport signal sur bruit de quantification (SQNR)** est une mesure de la qualité du signal après quantification. Il est défini par :

$$
SQNR = \frac{S_0}{N_0} = 3L^2 \frac{m^2(t)}{m_p^2}
$$

(référence : Équation 5.33, page 307).

## **Interprétation**
- Un **nombre de niveaux de quantification \( L \) plus élevé** réduit le bruit de quantification.
- Une **quantification fine** améliore le **SQNR**, ce qui signifie un meilleur rapport signal/bruit.
- Dans un **CAN idéal**, le bruit de quantification est **uniformément distribué** et peut être modélisé comme un bruit aléatoire.

**Conclusion** : Le bruit de quantification est un facteur critique dans la conversion analogique-numérique, et il doit être minimisé pour assurer une haute fidélité du signal converti.


### Applications: Modulations analogiques d’impulsions  
## Modulation par impulsions codées (*Pulse Code Modulation*; PCM)

##  Multiplexage temporel